import os
import secrets
import string
import json
from sqlalchemy import case
from app import db
from app.model import User, Classes, ClassTeachers, FinalResult, EvaluationResult, PretestResult, Score
from flask_login import current_user
from flask import abort, current_app, flash, redirect, url_for, request
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash
from app.excel_import import SpreadsheetError, read_student_rows

def _generate_token():
    suffix = ''.join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(6))
    return f'#CLS-{suffix}'


def get_amount_student_by_teacher(user_id):
    teacher = User.query.get(user_id)
    if not teacher or teacher.level != 1:
        return 0

    class_ids = [rel.class_id for rel in teacher.teacher_classes]

    if not class_ids:
        return 0

    amount_student = (
        User.query
        .filter(
            User.level == 0,
            User.class_id.in_(class_ids)
        )
        .count()
    )

    return amount_student


def get_amount_class_by_teacher(user_id):
    teacher = User.query.get(user_id)
    if not teacher or teacher.level != 1:
        return 0

    amount_class = len(teacher.teacher_classes)
    return amount_class


def get_my_classes(user_id):
    teacher = User.query.get(user_id)
    if not teacher or teacher.level != 1:
        return []

    classes = []
    for rel in teacher.teacher_classes:
        kelas = rel.class_obj
        if not kelas:
            continue

        total_siswa = User.query.filter(
            User.level == 0,
            User.class_id == kelas.id
        ).count()

        sudah_pretest = PretestResult.query.join(User).filter(
            User.class_id == kelas.id,
            User.level == 0
        ).count()

        classes.append({
            'id': kelas.id,
            'name': kelas.name,
            'school': kelas.school,
            'token': kelas.token,
            'kkm': kelas.kkm,
            'total_siswa': total_siswa,
            'sudah_pretest': sudah_pretest,
        })

    return classes


def get_teacher_dashboard_overview(teacher_id):
    teacher = User.query.get(teacher_id)
    if not teacher or teacher.level != 1:
        return {
            'total_students': 0,
            'pretest_done': 0,
            'evaluation_done': 0,
            'final_analysis_done': 0,
            'pretest_percent': 0,
            'evaluation_percent': 0,
            'final_percent': 0,
            'average_score': 0,
            'classification': {'Rendah': 0, 'Sedang': 0, 'Tinggi': 0, 'Belum': 0},
            'classification_percent': {'Rendah': 0, 'Sedang': 0, 'Tinggi': 0, 'Belum': 0},
            'classes': [],
            'top_students': [],
        }

    class_ids = [rel.class_id for rel in teacher.teacher_classes if rel.class_obj]
    students = (
        User.query.filter(User.level == 0, User.class_id.in_(class_ids)).all()
        if class_ids else []
    )
    student_ids = [student.id for student in students]
    total_students = len(student_ids)

    def count_results(model):
        if not student_ids:
            return 0
        return model.query.filter(model.user_id.in_(student_ids)).count()

    pretest_done = count_results(PretestResult)
    evaluation_done = count_results(EvaluationResult)
    final_analysis_done = count_results(FinalResult)

    def percent(value):
        return round(value * 100 / total_students) if total_students else 0

    all_scores = [
        score.value for student in students for score in student.scores
        if score.value is not None
    ]
    average_score = round(sum(all_scores) / len(all_scores)) if all_scores else 0

    classification = {'Rendah': 0, 'Sedang': 0, 'Tinggi': 0, 'Belum': 0}
    class_labels = {0: 'Rendah', 1: 'Sedang', 2: 'Tinggi'}
    for student in students:
        classification[class_labels.get(student.klasifikasi, 'Belum')] += 1
    classification_percent = {
        label: percent(value) for label, value in classification.items()
    }

    class_summaries = []
    for rel in teacher.teacher_classes:
        kelas = rel.class_obj
        if not kelas:
            continue
        class_students = [s for s in students if s.class_id == kelas.id]
        class_ids_here = [s.id for s in class_students]
        class_pretest = (
            PretestResult.query.filter(PretestResult.user_id.in_(class_ids_here)).count()
            if class_ids_here else 0
        )
        class_scores = [
            score.value for student in class_students for score in student.scores
            if score.value is not None
        ]
        class_summaries.append({
            'id': kelas.id,
            'name': kelas.name,
            'school': kelas.school,
            'total_students': len(class_students),
            'pretest_done': class_pretest,
            'pretest_percent': round(class_pretest * 100 / len(class_students)) if class_students else 0,
            'average_score': round(sum(class_scores) / len(class_scores)) if class_scores else 0,
        })

    top_students = []
    for student in students:
        scores = [score.value for score in student.scores if score.value is not None]
        if not scores:
            continue
        top_students.append({
            'id': student.id,
            'name': student.full_name,
            'class_name': student.student_class_obj.name if student.student_class_obj else '-',
            'average': round(sum(scores) / len(scores)),
        })
    top_students.sort(key=lambda item: item['average'], reverse=True)

    return {
        'total_students': total_students,
        'pretest_done': pretest_done,
        'evaluation_done': evaluation_done,
        'final_analysis_done': final_analysis_done,
        'pretest_percent': percent(pretest_done),
        'evaluation_percent': percent(evaluation_done),
        'final_percent': percent(final_analysis_done),
        'average_score': average_score,
        'classification': classification,
        'classification_percent': classification_percent,
        'classes': class_summaries,
        'top_students': top_students[:5],
    }


def get_final_analysis(class_id: int) -> list[dict]:
    results = (
        db.session.query(
            User.id.label('user_id'),
            User.full_name,
            PretestResult.id.label('pretest_id'),
            EvaluationResult.id.label('evaluation_id'),
            FinalResult.ai_analysis.label('final_analysis')
        )
        # Join ke tabel PretestResult
        .outerjoin(PretestResult, PretestResult.user_id == User.id)
        # Join ke tabel EvaluationResult
        .outerjoin(EvaluationResult, EvaluationResult.user_id == User.id)
        # Join ke tabel FinalResult
        .outerjoin(FinalResult, FinalResult.user_id == User.id)
        .filter(
            User.class_id == class_id,   # Filter sesuai id kelas
            User.level == 0,             # 0 = siswa
        )
        .order_by(
            # Urutkan: Siswa yang sudah punya final analysis ditaruh di atas
            case((FinalResult.ai_analysis == None, 1), else_=0).asc(),  
            User.full_name.asc(),
        )
        .all()
    )

    return [
        {
            'user_id'             : row.user_id,
            'full_name'           : row.full_name,
            'pretest_done'        : row.pretest_id is not None,
            'evaluation_done'     : row.evaluation_id is not None,
            'final_analysis_done' : row.final_analysis is not None,
        }
        for row in results
    ]

def get_student_final_analysis_detail(teacher_id, user_id):
    if teacher_id != current_user.id:
        abort(403)

    # 1. Validasi siswa dan kelas guru
    student = User.query.filter_by(id=user_id, level=0).first_or_404()
    teacher_class_ids = [ct.class_id for ct in current_user.teacher_classes]
    if student.class_id not in teacher_class_ids:
        abort(403)

    # 2. Ambil data murni dari FinalResult saja
    final_test = FinalResult.query.filter_by(user_id=user_id).first()
    if not final_test:
        return None

    # 3. Return data student dan ai_analysis saja
    return {
        'student':     student,
        'ai_analysis': json.loads(final_test.ai_analysis) if final_test.ai_analysis else None
    }

def create_class(teacher_id):
    if teacher_id != current_user.id:
        flash("Akses ditolak.", "danger")
        return redirect(url_for('my_classes', user_id=teacher_id))

    name = request.form.get('name', '').strip()
    school = request.form.get('school', '').strip()
    kkm_str = request.form.get('kkm', '75').strip()

    if not name or not school:
        flash("Nama kelas dan sekolah wajib diisi.", "danger")
        return redirect(url_for('my_classes', user_id=teacher_id))

    try:
        kkm = int(kkm_str)
    except ValueError:
        kkm = 75

    token = _generate_token()
    while Classes.query.filter_by(token=token).first():
        token = _generate_token()

    kelas = Classes(name=name, school=school, kkm=kkm, token=token)
    db.session.add(kelas)
    db.session.flush()

    bridge = ClassTeachers(teacher_id=teacher_id, class_id=kelas.id)
    db.session.add(bridge)
    db.session.commit()

    flash(f"Kelas '{name}' berhasil dibuat. Token: {token}", "success")
    return redirect(url_for('my_classes', user_id=teacher_id))


def edit_class(teacher_id, class_id):
    if teacher_id != current_user.id:
        flash("Akses ditolak.", "danger")
        return redirect(url_for('my_classes', user_id=teacher_id))

    teacher_class_ids = [ct.class_id for ct in current_user.teacher_classes]
    if class_id not in teacher_class_ids:
        flash("Kelas bukan wewenang Anda.", "danger")
        return redirect(url_for('my_classes', user_id=teacher_id))

    kelas = Classes.query.get(class_id)
    if not kelas:
        flash("Kelas tidak ditemukan.", "danger")
        return redirect(url_for('my_classes', user_id=teacher_id))

    name = request.form.get('name', '').strip()
    school = request.form.get('school', '').strip()
    kkm_str = request.form.get('kkm', '75').strip()

    if not name or not school:
        flash("Nama kelas dan sekolah wajib diisi.", "danger")
        return redirect(url_for('my_classes', user_id=teacher_id))

    try:
        kkm = int(kkm_str)
    except ValueError:
        kkm = 75

    kelas.name = name
    kelas.school = school
    kelas.kkm = kkm
    db.session.commit()

    flash(f"Kelas '{name}' berhasil diperbarui.", "success")
    return redirect(url_for('my_classes', user_id=teacher_id))


def delete_class(teacher_id, class_id):
    if not _teacher_owns_class(teacher_id, class_id):
        flash("Kelas bukan wewenang Anda.", "danger")
        return redirect(url_for('my_classes', user_id=teacher_id))

    kelas = Classes.query.get(class_id)
    if not kelas:
        flash("Kelas tidak ditemukan.", "danger")
        return redirect(url_for('my_classes', user_id=teacher_id))

    class_name = kelas.name
    User.query.filter_by(class_id=class_id).update(
        {'class_id': None}, synchronize_session=False
    )
    Score.query.filter_by(class_id=class_id).update(
        {'class_id': None}, synchronize_session=False
    )
    ClassTeachers.query.filter_by(class_id=class_id).delete(synchronize_session=False)
    db.session.delete(kelas)
    db.session.commit()

    flash(f"Kelas '{class_name}' berhasil dihapus.", "success")
    return redirect(url_for('my_classes', user_id=teacher_id))


def _teacher_owns_class(teacher_id, class_id):
    if teacher_id != current_user.id:
        return False
    return any(rel.class_id == class_id for rel in current_user.teacher_classes)


def _normalize_gender(value):
    value = (value or '').strip().upper()
    if not value:
        return 'L'
    if value in {'L', 'LAKI-LAKI', 'LAKI LAKI', 'PRIA', 'MALE'}:
        return 'L'
    if value in {'P', 'PEREMPUAN', 'WANITA', 'FEMALE'}:
        return 'P'
    return None


def import_students_from_excel(teacher_id, class_id, file_stream):
    if not _teacher_owns_class(teacher_id, class_id):
        raise PermissionError('Kelas bukan wewenang Anda.')
    if Classes.query.get(class_id) is None:
        raise LookupError('Kelas tidak ditemukan.')

    rows = read_student_rows(file_stream)
    created = 0
    errors = []
    seen_usernames = set()

    for row in rows:
        number = row['row']
        full_name = row['full_name']
        username = row['username']
        password = row['password']
        gender = _normalize_gender(row['gender'])

        if not full_name or not username or not password:
            errors.append(f'Baris {number}: nama, username, dan password wajib diisi.')
            continue
        if len(full_name) > 50:
            errors.append(f'Baris {number}: nama maksimal 50 karakter.')
            continue
        if len(username) > 50:
            errors.append(f'Baris {number}: username maksimal 50 karakter.')
            continue
        if gender is None:
            errors.append(f'Baris {number}: jenis kelamin harus L atau P.')
            continue
        username_key = username.lower()
        if username_key in seen_usernames:
            errors.append(f'Baris {number}: username "{username}" duplikat di file.')
            continue
        if User.query.filter_by(username=username).first() is not None:
            errors.append(f'Baris {number}: username "{username}" sudah digunakan.')
            continue

        user = User(
            username=username,
            full_name=full_name,
            level=0,
            gender=gender,
            class_id=class_id,
        )
        user.set_password(password)
        db.session.add(user)
        seen_usernames.add(username_key)
        created += 1

    try:
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        raise SpreadsheetError('Data gagal disimpan. Pastikan username unik dan coba lagi.') from exc

    return created, errors


def get_students_by_teacher(teacher_id):
    teacher = User.query.get(teacher_id)
    if not teacher or teacher.level != 1:
        return []

    class_ids = [ct.class_id for ct in teacher.teacher_classes]
    if not class_ids:
        return []

    classes_data = []
    for cid in class_ids:
        kelas = Classes.query.get(cid)
        if not kelas:
            continue
        students = User.query.filter_by(class_id=cid, level=0).order_by(User.full_name).all()
        if not students:
            continue

        student_ids = [s.id for s in students]
        all_scores = Score.query.filter(Score.user_id.in_(student_ids)).all()

        scores_by_user = {}
        all_chapters = set()
        for sc in all_scores:
            scores_by_user.setdefault(sc.user_id, []).append(sc)
            if sc.chapter:
                all_chapters.add(sc.chapter)
        total_bab = max(len(all_chapters), 1)

        student_list = []
        for s in students:
            user_scores = scores_by_user.get(s.id, [])
            quiz_val = None
            chapters_done = set()
            total_val = 0
            for sc in user_scores:
                if sc.score_type == 'quiz' and quiz_val is None:
                    quiz_val = sc.value
                if sc.chapter:
                    chapters_done.add(sc.chapter)
                total_val += sc.value

            student_list.append({
                'id': s.id,
                'full_name': s.full_name,
                'gender': s.gender,
                'pretest_done': s.pretest_result is not None,
                'kualifikasi': {0: 'Rendah', 1: 'Sedang', 2: 'Tinggi'}.get(s.klasifikasi),
                'quiz_score': quiz_val,
                'materi_selesai': len(chapters_done),
                'total_bab': total_bab,
                'total_score': total_val,
            })
        classes_data.append({
            'class_id': kelas.id,
            'class_name': kelas.name,
            'school': kelas.school,
            'students': student_list,
        })

    return classes_data


def _evaluation_score(pretest_result, final_result):
    if not pretest_result or pretest_result.score is None or not final_result or not final_result.ai_analysis:
        return None
    try:
        improvement = json.loads(final_result.ai_analysis).get('peningkatan_skor')
    except (ValueError, TypeError, AttributeError):
        return None
    if isinstance(improvement, (int, float)) and not isinstance(improvement, bool):
        return round(pretest_result.score + improvement)
    return None


def get_grades_recap(teacher_id):
    teacher = User.query.get(teacher_id)
    if not teacher or teacher.level != 1:
        return [], [], []

    class_ids = [ct.class_id for ct in teacher.teacher_classes]
    if not class_ids:
        return [], [], []

    all_student_ids = []
    for cid in class_ids:
        ids = [row[0] for row in User.query.filter_by(class_id=cid, level=0).with_entities(User.id).all()]
        all_student_ids.extend(ids)

    if not all_student_ids:
        return [], [], []

    chapters = db.session.query(Score.chapter).filter(
        Score.user_id.in_(all_student_ids),
        Score.chapter.isnot(None),
        Score.score_type == 'quiz',
    ).distinct().order_by(Score.chapter).all()
    chapter_list = [row.chapter for row in chapters]
    material_keys = chapter_list
    material_labels = ['Evaluasi' if chapter == 'evaluation' else chapter for chapter in chapter_list]

    all_scores = Score.query.filter(
        Score.user_id.in_(all_student_ids),
        Score.chapter.isnot(None),
        Score.score_type == 'quiz',
    ).all()

    scores_by_user = {}
    for sc in all_scores:
        scores_by_user.setdefault(sc.user_id, {})[sc.chapter] = sc.value

    recap = []
    for ct in teacher.teacher_classes:
        kelas = ct.class_obj
        if not kelas:
            continue
        students = User.query.filter_by(class_id=kelas.id, level=0).order_by(User.full_name).all()
        if not students:
            continue

        student_grades = []
        for s in students:
            user_scores = scores_by_user.get(s.id, {})
            pretest_score = s.pretest_result.score if s.pretest_result else None
            evaluation_score = _evaluation_score(s.pretest_result, s.final_result)
            scores_dict = {}
            total = 0
            count = 0
            for ch in chapter_list:
                val = user_scores.get(ch)
                scores_dict[ch] = val
                if val is not None:
                    total += val
                    count += 1
            for val in (pretest_score, evaluation_score):
                if val is not None:
                    total += val
                    count += 1
            avg = round(total / count) if count > 0 else 0
            student_grades.append({
                'id': s.id,
                'full_name': s.full_name,
                'pretest_done': s.pretest_result is not None,
                'pretest_score': pretest_score,
                'evaluation_done': s.evaluation_result is not None,
                'evaluation_score': evaluation_score,
                'scores': scores_dict,
                'total': total,
                'avg': avg,
            })

        recap.append({
            'class_id': kelas.id,
            'class_name': kelas.name,
            'school': kelas.school,
            'students': student_grades,
        })

    return recap, material_labels, material_keys


def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def valid_image_content(file):
    header = file.stream.read(12)
    file.stream.seek(0)
    return (
        header.startswith(b'\x89PNG\r\n\x1a\n')
        or header.startswith(b'\xff\xd8\xff')
        or header.startswith((b'GIF87a', b'GIF89a'))
    )


def teacher_profile(user_id):
    user = User.query.get_or_404(user_id)
    return user


def update_teacher_profile(user_id):
    if user_id != current_user.id:
        abort(403)

    user = User.query.get_or_404(user_id)

    if 'avatar' in request.files:
        file = request.files['avatar']
        if file and file.filename != '':
            if allowed_file(file.filename) and valid_image_content(file):
                filename = secure_filename(file.filename)
                ext = filename.rsplit('.', 1)[-1].lower()
                project_root = os.path.dirname(current_app.root_path)
                upload_folder = os.path.join(project_root, 'resources', 'images', 'avatars')
                os.makedirs(upload_folder, exist_ok=True)
                new_filename = f"teacher_{user_id}.{ext}"
                file.save(os.path.join(upload_folder, new_filename))
                user.image = new_filename

    password = request.form.get('password', '').strip()
    password_confirm = request.form.get('password_confirm', '').strip()
    if password and password == password_confirm:
        user.set_password(password)
    elif password and password != password_confirm:
        flash("Password tidak cocok.", "danger")
        return redirect(url_for('teacher_profile_route', user_id=user_id))

    db.session.commit()
    flash("Profil berhasil diperbarui.", "success")
    return redirect(url_for('teacher_profile_route', user_id=user_id))
