# AGENTS.md

## Project overview

Flask MVC app ("Veldora") for numeracy pretest & AI-driven student analysis.
MySQL/MariaDB via SQLAlchemy, Jinja2 templates, DeepSeek AI integration.
No CI, no tests, no test framework in requirements.txt.
`AGENTS.md` is in `.gitignore` — changes stay local, won't appear in git.

## Setup & run

```bash
cp .env.example .env   # no .env.example exists in repo; copy/adapt an existing .env or create one
python3 -m venv venv && source venv/bin/activate   # existing venv is Python 3.14
pip install -r requirements.txt

# MySQL must be running. Create the DB first:
mysql -u root -p -e "CREATE DATABASE IF NOT EXISTS edudaya CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

# First-time only: init migrations (migrations/ is gitignored)
export FLASK_APP=server.py
flask db init
flask db migrate -m "Initial migration"
flask db upgrade

# Seed (order matters: classes first, then users)
export PYTHONPATH=.
python seeders/class_seed.py   # idempotent (dedupes by token)
python seeders/user_seed.py    # WIPES Users + ClassTeachers on every run

# Run
export FLASK_APP=server.py
flask run --host=127.0.0.1 --port=5000
```

## Env vars (.env)

| Variable | Required |
|---|---|
| DB_HOST, DB_PORT, DB_DATABASE, DB_USERNAME, DB_PASSWORD | Yes |
| JWT_SECRET, SECRET_KEY | Yes |
| DEEPSEEK_API_KEY | Only for AI batch analysis (pretest + final) |

- AI is **DeepSeek**, not OpenRouter: `ArtificialController.py` calls `api.deepseek.com` and reads `os.getenv("DEEPSEEK_API_KEY")`. The repo's `.env` currently sets `OPENROUTER_API_KEY` instead, so batch analysis reports "Kunci API DeepSeek belum dikonfigurasi" until the var is renamed.
- `config.py` casts `JWT_SECRET` via `str(os.environ.get("JWT_SECRET"))` — missing var becomes `"None"` (string), not an error.

## Architecture

```
server.py             →  `from app import app`; does NOT call `.run()`
app/
  __init__.py         →  Flask(template_folder='../resources/views', static_folder='../resources')
                         `application = app` (alias used by passenger_wsgi.py)
                         Creates db, csrf, migrate, seeder, jwt, login_manager.
                         Imports all models + routes at bottom.
  routes.py           →  ALL routes live in this one file (~1000 lines), incl. inline quiz
                         answer keys & scoring — duplicated verbatim for Bab 1 and Bab 2.
  controller/         →  Home, User, Pretest, Evaluation, Activity, Learning, Artificial (DeepSeek AI)
                         dashboard/ → Admin, Student, Teacher dashboard controllers.
                         __init__.py wildcard re-exports them all.
  model/              →  User, Score, Classes, FinalResult, ActivityLog, PretestResult,
                         ClassTeachers, EvaluationResult. __init__.py wildcard re-exports.
  decorator/utils.py  →  level_required(role): 0=siswa, 1=guru, 2=admin
  response.py         →  success() / badRequest() JSON helpers
resources/
  views/              →  Jinja2 templates
  css/, js/, images/  →  Static assets (static_folder points here)
```

### Roles & klasifikasi

- `User.level`: 0=siswa, 1=guru, 2=admin (enforced via `@level_required`).
- `User.klasifikasi`: 0=low, 1=medium, 2=high — set by teacher/admin choice, or by AI analysis (`LEVEL_MAP` in ArtificialController). Routes render `learning/{low|medium|high}/...` templates from this value.

### Relationships

- **Student → Class**: `User.class_id` → `Classes.id` (direct FK, nullable, one-to-many)
- **Teacher → Class**: via `ClassTeachers` bridge (many-to-many)
- **Student → results**: `pretest_result`, `evaluation_result`, `final_result` (one-to-one via `uselist=False`); `scores` and `activity_logs` (one-to-many)

## Seeders: order matters

1. `class_seed.py` — sample Classes keyed by token (`#SDN-BJM1`, `#SDN-BJB1`, `#SDN-BJM3`); idempotent.
2. `user_seed.py` — **deletes all Users and ClassTeachers first**, then recreates sample users (SuperAdmin / ContohGuru / SiswaProgres / SiswaBiasa, password `12345`). Depends on Classes existing. Run with `PYTHONPATH=.`.

## Gotchas

- **`migrations/` is gitignored** — every fresh clone must `flask db init` + `flask db migrate` + `flask db upgrade`.
- **`python3 server.py` won't start the server** — `server.py` only imports `app`; use `flask run`. (README says `python3 server.py` works; it doesn't.)
- **`PYTHONPATH=.` is required** for seeders and any script that imports `app` or `config` directly.
- **Wildcard imports everywhere** — models/controllers are re-exported via `__init__.py`. Adding a new model/controller requires updating the matching `__init__.py`.
- **CSRF is enabled globally** (`Flask-WTF`). HTML forms need a hidden `csrf_token` input; fetch-based POSTs must send the `X-CSRFToken` header (see existing views/JS). POSTs without a token fail.
- **`config.py` runs `load_dotenv()` at module level** — env must be loaded before `app` is imported.
- **Quiz scoring is duplicated** in `routes.py` — Bab 1 and Bab 2 answer keys/scoring are separate copies; edit both.
- **Deployment**: `passenger_wsgi.py` (gitignored, local-only) imports `application` from `app` for cPanel/Passenger.
